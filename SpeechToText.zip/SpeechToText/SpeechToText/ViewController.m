//
//  ViewController.m
//  SpeechToText
//
//  Created by Bommavaram, Sarika  . (UMKC-Student) on 6/19/15.
//  Copyright (c) 2015 Bommavaram, Sarika  . (UMKC-Student). All rights reserved.
//

#import "ViewController.h"

#import "AFHTTPRequestOperationManager.h"

#define BASE_URL "http://api.openweathermap.org/data/2.5/weather"


@interface ViewController ()
@property (strong, nonatomic) IBOutlet UILabel *messageLabel;
@property (strong, nonatomic) IBOutlet UITextField *searchTextField;
@property (strong, nonatomic) IBOutlet UITableView *tableViewDisplayDataArray;
@property (strong, nonatomic) IBOutlet UIButton *recordButton;

@end

const unsigned char SpeechKitApplicationKey[] = "d192a804ff3f854a901a194c23e76bf7bbc6c9d440a8d396c7179aa92a98a3fb2b4bff2a8a85741a9f8e66c275d2b930988304d82bd76ff2ee099b19a13e14cc";

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
        [SpeechKit setupWithID: @"NMDPTRIAL_ssarika535_gmail_com20150619141245"
                          host:@"sslsandbox.nmdp.nuancemobility.net"
                          port:443
                        useSSL:YES
                      delegate:nil];
        
        // Set earcons to play
        SKEarcon* earconStart	= [SKEarcon earconWithName:@"earcon_listening.wav"];
        SKEarcon* earconStop	= [SKEarcon earconWithName:@"earcon_done_listening.wav"];
        SKEarcon* earconCancel	= [SKEarcon earconWithName:@"earcon_cancel.wav"];
        
        [SpeechKit setEarcon:earconStart forType:SKStartRecordingEarconType];
        [SpeechKit setEarcon:earconStop forType:SKStopRecordingEarconType];
        [SpeechKit setEarcon:earconCancel forType:SKCancelRecordingEarconType];
    
    
    self.messageLabel.text = @"Tap on the mic";
  
    
    if (!self.tableViewDisplayDataArray) {
        self.tableViewDisplayDataArray = [[NSMutableArray alloc] init];
    }
    
    
  
    
    self.searchTextField.returnKeyType = UIReturnKeySearch;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)tappedVoiceButton:(id)sender {
    
    self.recordButton.selected = !self.recordButton.isSelected;
    
    // This will initialize a new speech recognizer instance
    if (self.recordButton.isSelected) {
        self.voiceSearch = [[SKRecognizer alloc] initWithType:SKSearchRecognizerType
                                                    detection:SKShortEndOfSpeechDetection
                                                     language:@"en_US"
                                                     delegate:self];
    }
    
    // This will stop existing speech recognizer processes
    else {
        if (self.voiceSearch) {
            [self.voiceSearch stopRecording];
            [self.voiceSearch cancel];
        }
    }
}


# pragma mark - SKRecognizer Delegate Methods

- (void)recognizerDidBeginRecording:(SKRecognizer *)recognizer {
    self.messageLabel.text = @"Listening..";
}

- (void)recognizerDidFinishRecording:(SKRecognizer *)recognizer {
    self.messageLabel.text = @"Done Listening..";
}

- (void)recognizer:(SKRecognizer *)recognizer didFinishWithResults:(SKRecognition *)results {
    long numOfResults = [results.results count];
    
    if (numOfResults > 0) {
        // update the text of text field with best result from SpeechKit
        self.searchTextField.text = [results firstResult];
        
    }
    
    self.recordButton.selected = !self.recordButton.isSelected;
    
    if (self.voiceSearch) {
        [self.voiceSearch cancel];
    }
}

- (void)recognizer:(SKRecognizer *)recognizer didFinishWithError:(NSError *)error suggestion:(NSString *)suggestion {
    self.recordButton.selected = NO;
    self.messageLabel.text = @"Connection error";
   
    
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error"
                                                    message:[error localizedDescription]
                                                   delegate:nil
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles:nil];
    [alert show];
}

@end
